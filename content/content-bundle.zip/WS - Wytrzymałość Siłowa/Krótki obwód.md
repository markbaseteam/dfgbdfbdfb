# LVL 1

**Czas:** 150 min
**Miejsce:** Przewieszona, dość wysokoa ściana
**Cel:** Kształtowanie wytrzymałości siłowej i umiejętności restowania.

Na treningu robisz 3 siłowe obwody z wyznaczonymi stopniami. W sumie 14-16 ruchów. Każdy 3 razy z przerwą do pełnego wypoczynku (minimum 10 min.)

Obwód podzielony jest na dwie części, z miejscem odpoczynkowym po środku.
Pierwsza część z akcentem na Twoje słabe strony. Druga część na Twoje mocne strony. Po środku rest, ale trochę niewygodny (tak żebyś nie mógł zrestować do zera)
