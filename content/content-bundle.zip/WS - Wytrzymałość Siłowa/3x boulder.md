# LVL 1
**Czas:** ok. 120 min
**Miejsce:** Ścianka z ułożonymi baldami, najlepiej takimi, które już znasz
**Cel:** Kształtowanie wytrzymałości siłowej. Dopracowanie ruchu do perfekcji mimo zmęczenia.

Trening poprzedź porządną rozgrzewką i patentowaniem baldów.

Wybierasz 6 siłowych baldów. Najlepiej takich, które już znasz. Połowa z akcentem na Twoje słabe strony a połowa z akcentem na mocne. Baldy mają być o różnym charakterze, ale bez połogów. Bez bardzo trickowych ruchów i no-hand-restów.

Każdy bald powtarzasz 3 razy z rzędu. Przerwa tylko na szybkie sięgnięcie do woreczka. Postaraj się tak dobrać trudność, żeby przy trzeciej wstawce nie było już szans na zatopowanie. Kolejność dobierz tak, żeby te pod Ciebie przeplatały się z tymi, w których nie czujesz się perfekcyjnie. Charakter baldów też powinien się przeplatać.
Pilotażowo zacznij od najłatwiejszego balda, żeby zobaczyć, czy nie przesadziłeś z trudnością.

Przerwy przy zmianie balda - 10 min
Przerwy między wstawkami w balda - 2-5s
Ilość Serii - 1
