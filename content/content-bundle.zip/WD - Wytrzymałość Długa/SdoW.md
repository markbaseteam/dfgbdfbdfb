---
tags:
aliases: Seria do wyczerpania
---
# SdoW

Seria do wyczerpania

Robisz 30-40 ruchów w lekkim przewieszeniu po dobrych chwytach.
Nogi po wszystkich stopniach. Staraj się dobierać chwyty w ten sposób, aby zachować ciągowy charakter (bez wyraźnych cruxów i restów). Podczas wspinania staraj się pracować nad płynnością ruchu. Celuj tak, aby pod koniec wybierało Cię mocno na samych klamach. Chwyty dobieraj różnorodne, ale raczej z przewagą takich, które nie kasują skóry i do których trzeba się dobrze ustawiać (odciągi i podchwyty).  